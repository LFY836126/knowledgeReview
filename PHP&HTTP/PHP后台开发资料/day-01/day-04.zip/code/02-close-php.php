<?php

// 如果这个PHP文件只是写PHP，不会产生混编情况，这时删除结束标记，这样避免额外产生空格

$message = 'hello';

echo $message;













