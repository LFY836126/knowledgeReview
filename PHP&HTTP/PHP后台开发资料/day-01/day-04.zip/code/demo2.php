<h1><?php $str = 123; ?></h1>
