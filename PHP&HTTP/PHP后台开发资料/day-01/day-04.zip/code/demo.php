<!-- <?php echo 'Hello world'; ?> -->
<?php echo date('Y-m-d'); ?>
<!-- 解压 PHP，loadmodule，addtype -->

<!-- ↓↓↓↓↓↓↓↓↓↓ PHP ↓↓↓↓↓↓↓↓↓↓ -->

<!-- Hello world -->
2017-10-21
<!-- 解压 PHP，loadmodule，addtype -->
