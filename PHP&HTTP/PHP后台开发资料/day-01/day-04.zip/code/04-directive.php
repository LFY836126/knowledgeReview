<?php

// 指令式的语句

if (true) {
  echo "hello ";
}


if (true) :

echo "hello ";

else :

echo "world ";

endif;
